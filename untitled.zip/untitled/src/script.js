function saludar(){
  alert("Bienvenido a tu app 🚀");
}